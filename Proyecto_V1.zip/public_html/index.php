<?php

    header("Location: ./Controllers/Controller_Inicio.php");
    //<meta http-equiv="refresh" content="0;url=./Controllers/Controller_Inicio.php">
    //window.location.replace("./Controllers/Controller_Inicio.php");

    //echo "<script>window.location.replace('./Controllers/Controller_Inicio.php')</script>";
    
?>
