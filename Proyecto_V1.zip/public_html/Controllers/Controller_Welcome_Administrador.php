<?php

	// Llamada a los documentos que componen la vista
	require_once "../Views/Header.php";
	require_once "../Views/Menu_Registrado.php";
	require_once "../Views/View_Welcome_Administrador.php";
	require_once "../Views/Footer.php";

?>
