<div class="container" align="center">
	<div>
		<header>
			<h1 style="margin-top: 5%;">Registro de usuarios</h1>
			<!-- <img src="../Images/favicon.ico" alt="foto" class="me-2 center" width="100" height="100"> -->
		</header>
		<div class="card-body" style="max-width: 40rem;">
			<br>
			<form method="post">
				<div class="form-group">
					<input type="text" name="nombre" class="form-control form-control-lg" placeholder="Nombre" autofocus style="text-align: center;">
					<!-- pattern="/^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$" -->
				</div>
				<br>
				<div class="form-group">
					<input type="text" name="apellido" class="form-control form-control-lg" placeholder="Apellido" style="text-align: center;">
				</div>
				<br>
				<div class="form-group">
					<input type="text" name="ciclo" class="form-control form-control-lg" placeholder="Ciclo Formativo" style="text-align: center;">
				</div>
				<br>
				<div class="form-group">
					<input type="password" name="password" class="form-control form-control-lg" placeholder="Contraseña" style="text-align: center;">
				</div>
				<br>
				<input type="submit" value="Registrarse" class="btn btn-outline-dark" style="width: 150px;">
			</form>
		</div>
	</div>
</div>
