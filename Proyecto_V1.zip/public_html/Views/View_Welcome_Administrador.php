<div class="container" align="center">
	<div>
		<div class="card-body">
			<h1>Administrador</h1>
			<?php
				session_start();
				var_dump($_SESSION);
			?>
		</div>
	</div>
</div>
