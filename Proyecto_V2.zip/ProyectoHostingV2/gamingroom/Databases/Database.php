<?php

	function conexion() {
		$servername = "gamingroom.com";
		$username   = "root";
		$password   = "";
		$dbname     = "gamingroom";

		try {
			$conn = new PDO("mysql:host=$servername; dbname=$dbname", $username, $password);
			// Set the PDO error mode to exception
			$conn -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		} catch(PDOException $e) {
			echo "Error: " . $e -> getMessage();
		}
		return $conn;
	}

?>
