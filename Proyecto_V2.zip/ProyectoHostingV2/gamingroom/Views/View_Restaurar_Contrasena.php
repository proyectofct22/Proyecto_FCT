<div class="container" align="center">
	<div>
		<header>
			<h1 style="margin-top: 5%;">Restaurar Contraseña</h1>
		</header>
		<div class="card-body" style="max-width: 40rem;">
			<br>
			<form method="post">
				<div class="form-group">
					<input type="text" name="nombre" class="form-control form-control-lg" placeholder="Usuario" autofocus required style="text-align: center;">
				</div>
				<br>
				<div class="form-group">
					<input type="password" name="password1" class="form-control form-control-lg" placeholder="Nueva contraseña" required style="text-align: center;">
				</div>
				<br>
				<div class="form-group">
					<input type="password" name="password2" class="form-control form-control-lg" placeholder="Repita la contraseña" required style="text-align: center;">
				</div>
				<br>
				<input type="submit" value="Confirmar restauración" class="btn btn-outline-dark" style="width: 250px;">
			</form>
		</div>
	</div>
</div>
