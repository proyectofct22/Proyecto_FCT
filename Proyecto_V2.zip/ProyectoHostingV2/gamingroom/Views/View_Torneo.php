<div class="container" align="center">
	<div>
		<header>
			<h1 style="margin-top: 5%;">Torneo</h1>
			<!-- <img src="../Images/favicon.ico" alt="foto" class="me-2 center" width="100" height="100"> -->
		</header>
		<div class="card-body" style="max-width: 40rem;">
			<!-- Contenido -->
			<?php
				// echo "http://" . $_SERVER['SERVER_NAME']."/ProyectoFct/Controllers/Controller_Torneo.php";
			?>
		</div>
	</div>
</div>
