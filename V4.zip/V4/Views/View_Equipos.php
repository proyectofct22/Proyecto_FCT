<div class="container" align="center">
	<div class="pt-5">
		<header>
			<h1 class="display-5 fw-bold pt-5">Equipos</h1>
		</header>
		<div class="card-body">
			<div class="row row-cols-1 row-cols-lg-4 text-white g-4 p-5">
				<?php
					$datosEquipo = datosEquipo($conexion);
						
					foreach($datosEquipo as $dato) {
						$fotoEquipo = "../Images/Equipos/".$dato[0].".png";
						echo '<div class="col">';
						if (file_exists($fotoEquipo)) {
							echo '<div class="card rounded-4 shadow-lg" style="background-image:url('.$fotoEquipo.');">';
						} else {
							echo '<div class="card rounded-4 shadow-lg" style="background-image:url(../Images/Equipos/Default.png);">';
						}
				?>
									<div class="p-5">
										<?php
											echo "<h3>" . $dato[0] . "</h3>";
										?>
									</div>
					
				<?php
							echo "</div>";
						echo "</div>";
					}
				?>
			</div>
		</div>
	</div>
</div>
