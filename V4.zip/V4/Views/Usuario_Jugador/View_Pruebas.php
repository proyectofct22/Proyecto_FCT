<!-- <div class="container pt-5">
	<div class="pt-5"> -->
		<?php
			// var_dump($_SESSION["editarTabla"]);
			// if ($_SESSION["editarTabla"] == false) {
				// echo "vea";
		?>
<!-- <table class="table table-bordered">
			<tr>
				<td width="200px">id</td>
				<td width="200px">titulo</td>
				<td width="200px">acciones</td>
			</tr>
			<tr>
				<td>a</td>
				<td>b</td>
				<td>
					<form method="post">
						<input type="submit" value="editar" name="editar" class="btn btn-dark">
					</form>
				</td>
			</tr>
		</table> -->

<?php
			// } else {
				// echo "edite";

?>
<!-- <table class="table table-bordered">
			<tr>
				<td width="200px">id</td>
				<td width="200px">titulo</td>
				<td width="200px">acciones</td>
			</tr>
			<tr>
				<td>a</td>
				<td>b</td>
				<td>
					<form method="post">
						<button value='' id='botonEditar' name='botonEditar' class='text-info text-decoration-none btn'><a href='../../Controllers/Usuario_Administrador/Controller_EditarDatoPartido_Admin.php' target='_self'><i class='bi bi-pencil-fill'></i></a></button>
					</form>
				</td>
			</tr>
		</table> -->

<?php
			// }
		?>
		
<!-- 	</div>
</div> -->