<div class="container" align="center">
	<div class="px-4 pt-5 my-5">
		<header>
			<h1 class="display-5 fw-bold pt-5">Editar perfil</h1>
		</header>
		<div class="card-body" style="max-width: 40rem;">
			<br>
			<form method="post" action="../Usuario_Jugador/Controller_Editar_Perfil.php">
				<div class="form-group">
					<input type="text" class="form-control form-control-lg textoCentrado" name="usuario" pattern="^([A-Za-z])([A-Za-z0-9-._]){2,12}$" placeholder="Nuevo Usuario" autofocus>
				</div>
				<br>
				<div class="form-group">
					<input type="email" class="form-control form-control-lg textoCentrado" name="email"pattern="^[a-z][0-9a-z-._]+[a-z0-9]@((gmail)|(hotmail)|(educa.madrid))\.((com)|(es)|(org))$" placeholder="Nuevo Email">
				</div>
				<br>
				<div class="form-group">
					<input type="password" class="form-control form-control-lg textoCentrado" name="password" pattern="^[A-Za-z0-9.\-\$]{8,16}$" placeholder="Nueva Contraseña">
				</div>
				<br>
				<input type="submit" name="enviarDatos" value="Enviar" class="btn btn-primary btn-lg">
			</form>
			<br>
			<form method="POST" action="../Usuario_Jugador/Controller_Editar_Perfil.php" enctype="multipart/form-data">
				<div class="form-group">
					<label class="btn btn-outline-warning btn-lg" style="width: 275px;">Adjuntar imagen de perfil
						<input type="file" name="imagen" hidden>
					</label>
				</div>
				<br>
				<input type="submit" name="subirImagen" value="Subir Imagen" class="btn btn-outline-success btn-lg">
			</form>
		</div>
	</div>
</div>
