<style>
body{
	background-color: #8080803d;
}
</style>
<div class="row row-cols-1 row-cols-lg-3 align-items-stretch g-4 py-4">
	<div class="col">
	</div>

	<div class="col" style="margin-top: 100px;">
		<div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg" style="background-image: url('../../Images/FotoSobreNosotros.png');">
			<div class="d-flex flex-column h-100 p-3 pb-8 text-white text-shadow-1">
				<h2 class="pt-5 mt-5 mb-4 display-6 lh-1 fw-bold text-lg-center">ADMINISTRADOR</h2>
				<ul class="d-flex list-unstyled mt-auto">
					<li class="me-auto">
						<a href="#"><img src="../../Images/Logo.png" alt="Bootstrap" width="50" height="50" class="rounded-circle border border-white"></a>
					</li>
				</ul>
			</div>
		</div>
	</div>

	<div class="col">

	</div>
</div>