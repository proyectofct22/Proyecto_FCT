<style>
body{
	background-color: #8080803d;
}
</style>
<div align="center" style="margin-top: 100px">
<img src="../../Images/FotoTorneos/LOL.png">
</div>
