<!-- 
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
	<a href="../Controllers/Controller_Inicio.php" class="d-flex align-items-center mb-2 mb-lg-0 text-light text-decoration-none botonLogo">
		<img src="../Images/Logo.png" class="nav-link ms-5 me-2" width="50px" height="50px">Gaming Room
	</a>
</nav>
 -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top text-center px-3">
	<div class="container-fluid">
		<a href="../Controllers/Controller_Inicio.php" class="navbar-brand">
			<img src="../Images/Logo.png" width="50px" height="50px">Gaming Room
		</a>
	</div>
</nav>
