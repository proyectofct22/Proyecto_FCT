<?php

	// Llamada a los documentos que componen la vista
	require_once "../Views/Header.php";
	require_once "../Views/Menu_Sin_Registrar.php";
	require_once "../Views/View_Participa.php";
	require_once "../Views/Footer.php";

?>
