$(window).on("load",inicio);

function inicio(){
	$("#AsignarJugadores").on("click",proceso);
}

function proceso(){

	//  establecer conexión con el servidor
	let vequipo=$("#Equipos").val();
	let vjugador=$("#Jugadores").val();
		// solicitud a un programa php con paso de parámetros en variable
		// mediante post
	
		
	let dato=$.post("php/002.php",{equipo:vequipo,jugador:vjugador},respuesta);
		
}

function procesar(misDatos){
	location.reload();
}