<?php

	header("Location: ./Controllers/Controller_Inicio.php");

?>
